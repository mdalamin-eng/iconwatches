# No dedicated models needed yet - Order carries ip_address directly (see orders.models.Order).
# This app currently only provides the VisitorIPMiddleware in middleware.py.
# If you later want general site-analytics (not just order-related IPs),
# add a VisitorVisit model here and log it from the middleware.
