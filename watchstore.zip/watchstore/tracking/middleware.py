def get_client_ip(request):
    """Resolve the real client IP, respecting a reverse proxy (nginx/Cloudflare)."""
    forwarded = request.META.get("HTTP_X_FORWARDED_FOR")
    if forwarded:
        # X-Forwarded-For can be a chain: "client, proxy1, proxy2" - take the first.
        return forwarded.split(",")[0].strip()
    return request.META.get("REMOTE_ADDR")


class VisitorIPMiddleware:
    """Attaches request.visitor_ip to every request so views/signals can use it
    without recomputing it, and without trusting a spoofable header blindly
    unless X-Forwarded-For is actually set by a trusted proxy in production.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        request.visitor_ip = get_client_ip(request)
        return self.get_response(request)
